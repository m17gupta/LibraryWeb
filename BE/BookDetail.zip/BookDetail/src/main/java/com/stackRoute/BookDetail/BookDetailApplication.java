package com.stackRoute.BookDetail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookDetailApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookDetailApplication.class, args);
	}

}
