package com.stackRoute.studentDetail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentDetailApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentDetailApplication.class, args);
	}

}
